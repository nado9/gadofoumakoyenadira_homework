#include<stdio.h>
#include<cs50.h>

 int main(void)
 {
     long long i , n add, x2;
     int additionum, x2prod , sum;


{
    printf("votre numero de carte de credit");
    i= GetLongLong ();

}
   tandis que (i<0);
   pour(xadd=i ,additionum=0;xadd>o Addums+= xadd% 10);
   pour(x2= i /10 , x2prod =0 ; x2>0; x2>0 );

   {
        si (2 * (x2% 10 )> 9)
       {
           x2prod + = (X2% 10 )) / 10
           x2prod + =(x2%  10 )) % 10
       }
         autre
          x2prod + = 2 * (x2% 10);
   }
   sum=sum + x2prod;

   si (sum% 10 == 0 )
   {
       if(( i>= 340000000000000 && i< 350000000000000)
           printf ("American express \n ");

         else if(i>= 5100000000000000 && 5200000000000000)
           printf("Master card \n ");

          else if((i> = 4000000000000 && 5000000000000)
             printf("Visa \n" );

             autre
              printf("INVALID \n ");
}
  autre
     printf ("VALID \n ");

     return 0;
 }