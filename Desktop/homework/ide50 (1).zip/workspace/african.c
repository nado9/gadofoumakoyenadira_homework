#include<stdio.h>
#include<cs50.h>
 int main(void)
{
   int a = get_int(" a" );
   int b = get_int(" b" );
   int f = get_int(add a, b);
   printf("le resultat est:%i , f)
 }

 int add( int a , int b)
{
   return a+b;
}