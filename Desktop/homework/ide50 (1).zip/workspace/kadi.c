#include<stdio.h>
 int main(void)
 {
     int a= 7 ;
     if(a%2==0)
     {
         printf("a ,b are even");
     }
     else
     {
         printf("a , b are not even");
 }
 }
