#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<Ctype.h>
int main(void)
{
    stringname= get_string("Name:");
    char initials[4];
     int counter = 0;

    for(int i=0;i<strlen(name);i++)
    {
        if(isopper(name[i]))
    {
     initials[counter]=name[i];
     counter=counter+1;
    }
    }
    initials[counter]='\0';
    printf("%s\n",initials);
}

