#include<stdio.h>
#include<cs50.h>
 int main(void)
 {
  int age=get_int("give mee your age");
  printf ("my age is %i," age );
 }