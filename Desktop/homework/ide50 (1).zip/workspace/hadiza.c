 #include<stdio.h>
 #include<cs50.h>

 int main (void)
 {
 int i = get_int("i");
 for (int i=0;i<i; i++)
 {
 for (int j=0; j<=i; j++)
 {
    printf("#");
    }
       printf("\n");
 }
 }

