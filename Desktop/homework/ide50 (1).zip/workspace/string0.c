#include<stdio.h>
#include<cs50.h>

 int(main