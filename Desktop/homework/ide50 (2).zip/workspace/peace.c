#include<stdio.h>
#include<cs50.h>
#include<stdlib.h>

 int main(int argc , int argv[0])
 {
     (int i = 0, n = strlen(p); i < n; i++)
     int k = atoi(argv[1]);

  printf("%s\n",[0]);
}




