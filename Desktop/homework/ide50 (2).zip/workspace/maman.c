#include<stdio.h>
#include<cs50.h>
 int(int a; int b);
 int main(void)
 {
    int a=get_int("type a");
    int b=get_int("type b");
    printf("%i; \n" , a+b);
 }
   int addition(int a, int b)
   {
       return a=b;
   }