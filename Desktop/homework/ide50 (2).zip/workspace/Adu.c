#include<stdio.h>
#include<cs50.h>
  int subtraction (int a ,int b) ;
     int main(void)
{
   int a = get_int(" a ");
   int b = get_int(" b ");
   int z = subtraction( a, b);
   printf("le resultat est: %i \n", z);

}

int subtraction(int a , int b)
{
    return a-b;
}