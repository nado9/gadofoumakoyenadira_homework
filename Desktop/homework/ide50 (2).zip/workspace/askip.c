#include<stdio.h>
#include<cs50.h>
#include<string.h>

int main(void)
{
   string s= get_string("imput:");
   printf("after:");

   for(int i=0;n=strlen(s); i<n; i++)
   {
       if(islower(s[i]))
     {
         printf()
     }
   printf("%c %i\n",s[i], int s[i]);
   }
}