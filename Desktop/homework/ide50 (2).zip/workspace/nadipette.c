#include<stdio.h>
#include<cs50.h>
 int main(void)
 {
int a = get_int("type a: ");
int b = get_int("type b: ");
int c = get_int("type c: ");

 if( a<b && b<c
 {
   printf(" %i<%i<%i", a, b , c );
   }
 }