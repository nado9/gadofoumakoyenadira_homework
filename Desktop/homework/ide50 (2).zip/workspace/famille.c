#include<stdio.h>
#include<ctype.h>
  int main(void)
  {
      int nad1 ="n";
      if(lower(nad1))
      {
          printf("nad 1 = %c is an lower case" , nad 1);
      }
      else
      {
          printf("is not a lower case");
      }
  }
